AIDE Classic project layout.
All sources now directly under /src and /res.
If build button remains disabled, reopen AIDE, tap "Open existing project" -> select /VideoConverter.
