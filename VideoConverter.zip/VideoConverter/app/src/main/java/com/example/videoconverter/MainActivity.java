package com.example.videoconverter;

public class MainActivity extends androidx.appcompat.app.AppCompatActivity {
    // AIDE Kotlin 호환용 Java 스텁
}
